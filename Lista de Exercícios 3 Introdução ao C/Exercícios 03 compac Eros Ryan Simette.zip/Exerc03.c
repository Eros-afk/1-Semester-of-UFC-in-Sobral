#include<stdio.h>

int main(){
	int a;
	scanf("%f", &a);
	printf("Valor lido: %f\n", a);
}
/*Ocorreu um erro ao exibir o número inteiro solicitado*/