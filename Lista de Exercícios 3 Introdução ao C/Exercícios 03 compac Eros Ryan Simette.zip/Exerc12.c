#include<stdio.h>

int main(){
	char a;
	printf("Digite um caractere: ");
	scanf("%c", &a);
	printf("O caractere impresso e: \"%c\"\n",a);
}