#include<stdio.h>

float main(){
	float a;
	scanf ("%d", &a);
	printf("Valor lido: %d\n", a);
}
/*Ocorreu um erro ao exibir o número float solicitado*/