#include<stdio.h>

int main(){
	int a;
	scanf("%d", &a);
	printf("Valor lido: %d\n", a);
}