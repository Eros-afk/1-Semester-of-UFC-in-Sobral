#include<stdio.h>

/*Esse foi um bem legal de fazer*/

int main(){
	char a;
	scanf ("%c", &a);
	printf ("Valor lido: %d\n", a);
		printf ("Valor lido em octal: %o\n", a);
			printf ("Valor lido em hexadecimal: %x\n", a);

}