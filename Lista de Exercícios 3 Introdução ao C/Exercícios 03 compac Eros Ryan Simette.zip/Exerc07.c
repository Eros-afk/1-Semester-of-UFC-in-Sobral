#include<stdio.h>

int main(){
	int a, b;
	printf("Digite dois numeros:\n");
	scanf ("%d", &a);
	scanf ("%d", &b);

	printf ("Valor lido: %d | %d\n", a, b);
	printf ("Valor lido invertido: %d | %d\n", b, a);

}
