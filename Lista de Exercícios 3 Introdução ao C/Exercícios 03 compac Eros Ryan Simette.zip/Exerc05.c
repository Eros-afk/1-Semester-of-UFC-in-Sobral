#include<stdio.h>

int main(){
	double a;
	scanf("%lf", &a);
	printf ("Valor lido: %e", a);
}