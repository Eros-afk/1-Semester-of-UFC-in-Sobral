#include<stdio.h>
 
int main(){
	printf("Inicio do programa\nFIM");
	return 0;
}