#include <stdio.h>

int main() {
    printf("O tamanho em bytes do tipo char e: %lu\n", sizeof(char));
    printf("O tamanho em bytes do tipo char e: %lu\n", sizeof(int));
    printf("O tamanho em bytes do tipo char e: %lu\n", sizeof(float));
    printf("O tamanho em bytes do tipo char e: %lu\n", sizeof(double));

}