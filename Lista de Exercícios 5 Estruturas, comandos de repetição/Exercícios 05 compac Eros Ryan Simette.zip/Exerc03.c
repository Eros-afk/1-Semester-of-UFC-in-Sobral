#include<stdio.h>

int main(){
	int num;
	
	for(num = 0; num <= 100; num++){
		if(num%3 == 0){
		printf("Numeros multiplos de 3: %d\n", num);}
	}
}
