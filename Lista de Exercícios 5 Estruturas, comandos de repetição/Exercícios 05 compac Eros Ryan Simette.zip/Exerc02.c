#include<stdio.h>

int main(){
	int num; 
	
	for(num = 32; num <= 225; num++){
		printf("Caractere da tabela ASCII\t%d)\t%c\n", num, num);
	}
}
