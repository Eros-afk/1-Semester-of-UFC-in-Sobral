#include<stdio.h>

int main(){
	int a;
	printf("Digite um numero:\n", a);
	scanf("%d", &a);
	
	
	a%2 == 0;
	
	if(a%2 == 0)
	printf("NUMERO PAR\n", a);
	if(a%2 != 0)
	printf("NUMERO IMPAR\n");	
}
