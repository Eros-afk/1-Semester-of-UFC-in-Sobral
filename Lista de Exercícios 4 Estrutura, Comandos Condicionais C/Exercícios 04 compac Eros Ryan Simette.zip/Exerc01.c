#include<stdio.h>

int main(){
	float a;
	printf ("Digite um numero:\n");
	scanf ("%f", &a);
	if (a>10){
	printf("E MAIOR QUE 10!\n", a);
	}
	if (a<10){
	printf("NAO E MAIOR QUE 10!\n", a);
	}
}
