#include<stdio.h>

int main(){
	int A[5];
	int a;
	
	for(a=0; a<=4; a++){
	printf("O numero e %d\n", a);
}

}

